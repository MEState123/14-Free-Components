import Image from "next/image";
import one from "../images/one.jpg"
import two from "../images/two.jpg"
import three from "../images/three.jpg"
import four from "../images/four.jpg"
import camera from "../images/camera.png"
import illustration from "../images/drawing.png"
import video from "../images/video-production.png"
import Link from "next/link";
import yourLogo from "../images/your-logo-here.png"
import website1 from "../images/website1.jpg"
import website2 from "../images/website2.jpg"
import website3 from "../images/website3.jpg"
import website4 from "../images/website4.jpg"
import website5 from "../images/website5.jpg"
import website6 from "../images/website6.jpg"
import website7 from "../images/website7.jpg"
import website8 from "../images/website8.jpg"
import website9 from "../images/website9.jpg"
import website10 from "../images/website10.jpg"
import website11 from "../images/website11.jpg"
import website12 from "../images/website12.jpg"
import delivery from "../images/delivery-bike.png"
import quality from "../images/quality.png"
import responsiveDesigns from "../images/responsive-design.png"
import cleanui from "../images/ui.png"
import cleancode from "../images/clean-code.png"
import ModernTechnologies from "../images/computer.png"
import BudgetFriendly from "../images/wallet.png"


export function Navbar() {
  return (
    <main>
      {/* Header */}
      <div className="">
        <div className="text-white text-center w-[110px] py-[50px] rounded-[75px] font-bold text-xl shadow-2xl" id="Navbar">
          <ul>
            <Link href=""><li className="transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-105 hover:rounded-md duration-300">Home</li><Image src="" alt=""></Image> </Link>
            <Link href=""><li className="transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-105 hover:rounded-md duration-300">Portfolio</li></Link>
            <Link href=""><li className="transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-105 hover:rounded-md duration-300">Let's Talk</li></Link>
            <Link href=""><li className="transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-105 hover:rounded-md duration-300">Login</li></Link>
            <Link href=""><li className="transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-105 hover:rounded-md duration-300">Signup</li></Link>
          </ul>
        </div>
      </div>
    </main>
  )
}

export function Info_card() {
  return (
    <main>
      {/* Normal Card */}
      <div className="shadow-2xl w-[450px] pt-[24px] pb-[24px] px-[30px] text-start  font-extrabold capitalize rounded-[14px] bg-white">
        <h1 className="text-blue-400 text-4xl bg-white">CSS Flex & Grid</h1>
        <p className="text-gray-400 font-light bg-white mt-[12px]">Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel suscipit, tempore corporis dolorum animi repudiandae dolores mollitia ipsa unde corrupti facilis cum voluptatem rerum sit modi. In at nemo nesciunt minima voluptatibus nihil magni similique expedita placeat eum iste officia perspiciatis accusamus ut, ullam minus voluptate incidunt, beatae velit inventore!</p>
        <button className="px-[20px] mt-[12px] mr-[200px] rounded-[12px] py-[7px] bg-blue-200">Prev</button>
        <button className="px-[20px] mt-[6px] rounded-[12px] py-[7px] bg-blue-200">Next</button>
      </div>
    </main>
  )
}

export function Testimonial_Card() {
  return (
    <main>
      <div className="flex shadow-2xl w-[900px] pt-[24px] pb-[24px] px-[30px] text-start font-extrabold capitalize rounded-[14px] bg-white">
        <div className="bg-white align-center text-center">
          <div className="bg-black rounded-full">
            <Image className="rounded-lg" src={one} alt="image" width={250} height={250} ></Image>
          </div>
          <h1 className="bg-white text-xl font-extrabold">James Wohler</h1>
          <p className="bg-white font-semibold text-[15px] text-gray-500">Founder & CEO</p>
        </div>
        <div className="bg-white align-center text-center">
          <div className="bg-black rounded-full">
            <Image className="rounded-lg" src={two} alt="image" width={200} height={200} ></Image>
          </div>
          <h1 className="bg-white text-xl font-extrabold">Ayesha Qureshi</h1>
          <p className="bg-white font-semibold text-[15px] text-gray-500">Web Developer</p>
        </div>
        <div className="bg-white align-center text-center">
          <div className="bg-black rounded-full">
            <Image className="rounded-lg" src={three} alt="image" width={200} height={200} ></Image>
          </div>
          <h1 className="bg-white text-xl font-extrabold">Anabia Parvez</h1>
          <p className="bg-white font-semibold text-[15px] text-gray-500">marketing Expert</p>
        </div>
        <div className="bg-white align-center text-center">
          <div className="bg-black rounded-full">
            <Image className="rounded-lg" src={four} alt="image" width={200} height={200} ></Image>
          </div>
          <h1 className="bg-white text-xl font-extrabold">Bilal Hussain</h1>
          <p className="bg-white font-semibold text-[15px] text-gray-500">Entrepreneur</p>
        </div>
      </div>
    </main>
  )
}

export function Single_client_testimonial() {
  return (
    <main>
      <div className="py-[12px] shadow-2xl bg-white w-[500px] flex">
        <Image src={four} alt="Image" height={200} width={200}></Image>
        <div className="bg-white pt-[72px]">
          <h1 className="bg-white text-3xl">James Wohler</h1>
          <p className="bg-white text-gray-600  font-sans font-medium text-[16px]">Business Man | Entrepreneur </p>
        </div>
      </div>
    </main>
  )
}

export function Features() {
  return (
    <main>
      <div className="flex space-x-8 rounded-[24px] shadow-2xl bg-gray-100 px-[40px] py-[40px] w-[900px] ">
        <div className="shadow-lg rounded-[24px] p-[20px] w-[240px] text-center  bg-white">
          <Image className="bg-white ml-[50px]" src={camera} alt="" height={100} width={100}></Image>
          <h1 className="bg-white text-xl font-extrabold">Photo Shoot</h1>
          <p className="bg-white font-sans text-gray-600 "> Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
        <div className="shadow-lg rounded-[24px] p-[20px] w-[240px] text-center  bg-white">
          <Image className="bg-white ml-[50px] pt-[18px] pb-[12px]" src={video} alt="" height={80} width={80}></Image>
          <h1 className="bg-white text-xl font-extrabold">Video Shoot</h1>
          <p className="bg-white font-sans text-gray-600 "> Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
        <div className="shadow-lg rounded-[24px] p-[20px] w-[240px] text-center  bg-white">
          <Image className="bg-white ml-[50px] pt-[18px] pb-[12px]" src={illustration} alt="" height={80} width={80}></Image>
          <h1 className="bg-white text-xl font-extrabold">Illustration</h1>
          <p className="bg-white font-sans text-gray-600 "> Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </main>
  )
}

export function Faqs() {
  return (
    <main>
      <div className="bg-white shadow-2xl pb-[50px] rounded-3xl pt-[20px] w-1/3 text-center">
        <div className="bg-white flex justify-center space-x-1">
          <h1 className="bg-white text-3xl text-pink-600">Frequent</h1><h1 className="bg-white text-3xl ">Questions</h1>
        </div>
        <div className="flex bg-white mt-[24px]">
          <h1 className="bg-gradient-to-br from-pink-600 text-white font-sans text-xl text-center to-red-500 px-[14px] pt-[5px] justify-center align-middle mb-[28px] mt-[6px] ml-[8px]">1</h1>
          <div className="ml-[8px] ">
            <h1 className="bg-white text-start text-lg">Lorem ipsum dolor sit amet?</h1>
            <p className="bg-white text-start text-gray-600 font-sans">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequuntur, beatae!</p>
          </div>
        </div>
        <div className="flex bg-white mt-[24px]">
          <h1 className="bg-gradient-to-br from-pink-600 text-white font-sans text-xl text-center to-red-500 px-[14px] pt-[5px] justify-center align-middle mb-[28px] mt-[6px] ml-[8px]">2</h1>
          <div className="ml-[8px] ">
            <h1 className="bg-white text-start text-lg">Lorem ipsum dolor sit amet?</h1>
            <p className="bg-white text-start text-gray-600 font-sans">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequuntur, beatae!</p>
          </div>
        </div>
        <div className="flex bg-white mt-[24px]">
          <h1 className="bg-gradient-to-br from-pink-600 text-white font-sans text-xl text-center to-red-500 px-[14px] pt-[5px] justify-center align-middle mb-[28px] mt-[6px] ml-[8px]">3</h1>
          <div className="ml-[8px] ">
            <h1 className="bg-white text-start text-lg">Lorem ipsum dolor sit amet?</h1>
            <p className="bg-white text-start text-gray-600 font-sans">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequuntur, beatae!</p>
          </div>
        </div>
      </div>
    </main>
  )
}

export function Vertical_Testimonials() {
  return (
    <main>
      <div className="bg-white w-2/3 pb-[50px] pt-[30px] shadow-2xl rounded-2xl">
        <div className="flex bg-white">
          <Image src={four} alt="Image" width={150} height={150}></Image>
          <div className="bg-white space-y-1">
            <h1 className="bg-white text-xl ">Lorem ipsum dolor sit amet.</h1>
            <h1 className="bg-white text-[16px] text-gray-700">Entrepreneur | Business man</h1>
            <p className="bg-white text-gray-600 font-sans">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum consequatur ipsum pariatur sunt facere labore consectetur, ab incidunt quisquam, praesentium quos mollitia laudantium vel! Voluptates eius nisi vel labore ipsum.</p>
          </div>
        </div>
        <div className="flex bg-white mt-[14px]">
          <div className="bg-white space-y-1">
            <h1 className="bg-white text-xl text-end">Lorem ipsum dolor sit amet.</h1>
            <h1 className="bg-white text-[16px] text-gray-700 text-end">Web Developer</h1>
            <p className="bg-white text-gray-600 font-sans text-end">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae dolore est, voluptatem sed vitae dicta sequi! Eveniet laborum molestias ad reiciendis. Consequatur, sit temporibus optio eius facere inventore?</p>
          </div>
          <Image src={two} alt="Image" width={150} height={150}></Image>
        </div>
        <div className="flex bg-white mt-[14px]">
          <Image src={one} alt="Image" width={150} height={150}></Image>
          <div className="bg-white space-y-1">
            <h1 className="bg-white text-xl ">Lorem ipsum dolor sit amet.</h1>
            <h1 className="bg-white text-[16px] text-gray-700">Founder & CEO </h1>
            <p className="bg-white text-gray-600 font-sans">Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe ipsum, odio esse non itaque, voluptatem ducimus officia velit laboriosam natus, harum cupiditate rerum molestiae facilis.</p>
          </div>
        </div>
      </div>
    </main>
  )
}

export function Search_bar() {
  return (
    <main>
      <div className="w-2/3 py-[50px] flex bg-white justify-center rounded-2xl shadow-2xl">
        <input className="border-gray-400 border-2 pl-[12px] pr-[100px] outline-none" placeholder="Email Address" type="email" id="searchbar" />
        <button className="bg-cyan-700 text-white py-[14px] px-[20px] transition ease-linear hover:bg-cyan-900 hover:scale-105 hover:rounded-md duration-300">Subscribe</button>
      </div>
    </main>
  )
}

export function Footer() {
  return (
    <main>
      <div>
        <div className="py-[20px] flex bg-gradient-radial to-custom-purple from-[#4f0073]" id="footer">
          <div className="basis-1/2 ml-[150px]">
            <Image src={yourLogo} alt="your logo" width={450} height={450}></Image>
          </div>
          <div className=" basis-[130px] mt-[160px] text-white text-start font-bold text-lg">
            <ul id="footer-tools">
              <li>Home</li>
              <li>Portfolio</li>
              <li>Get Started</li>
              <li>Team</li>
            </ul>
          </div>
          <div className="basis-[130px] mt-[160px] text-start  text-white font-bold text-lg">
            <ul id="footer-tools">
              <li>Let's Talk</li>
              <li>Support</li>
              <li>Programming</li>
              <li>Design</li>
            </ul>
          </div>
          <div className="text-start mt-[160px] basis-[130px] text-white font-bold text-lg">
            <ul id="footer-tools">
              <li>Login</li>
              <li>Signup</li>
              <li>Responsivness</li>
              <li>Dynamic.SEO</li>
            </ul>
          </div>
        </div>
      </div>
    </main>
  )
}

export function Portfolio_showcase() {
  return (
    <main>
      <div className="">
        <div className="bg-purple-800 pl-[200px] pt-[20px]">
          <h1 className="text-7xl font-bold text-white" id="main-heading">Observe The Beauty.Variety.Elegance</h1>
        </div>
        <div className="flex flex-row bg-purple-800 pb-[24px]">
          <div className="basis-[1400px] flex pt-[50px] pl-[220px] mr-[36px]">
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website1} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website2} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
          </div>
        </div>
        <div className="flex flex-row bg-purple-800 pb-[24px]">
          <div className="basis-[1400px] flex pl-[220px] mr-[36px]">
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website3} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website4} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
          </div>
        </div>
        <div className="flex flex-row bg-purple-800 pb-[24px]">
          <div className="basis-[1400px] flex pl-[220px] mr-[36px]">
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website5} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website6} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
          </div>
        </div>
        <div className="flex flex-row bg-purple-800 pb-[24px]">
          <div className="basis-[1400px] flex pl-[220px] mr-[36px]">
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website7} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website8} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
          </div>
        </div>
        <div className="flex flex-row bg-purple-800 pb-[24px]">
          <div className="basis-[1400px] flex pl-[220px] mr-[36px]">
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website9} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website10} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
          </div>
        </div>
        <div className="flex flex-row bg-purple-800 pb-[24px]">
          <div className="basis-[1400px] flex pl-[220px] mr-[36px]">
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website11} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
            <div className="text-white bg-purple-900 basis-1/2 mr-[6px] transition ease-linear hover:scale-125 cursor-grabbing justify-center align-middle text-center">
              <Image src={website12} alt="Website 1"></Image>
              <button className="px-[24px] py-[8px] my-[4px] rounded-[23px] bg-custom-nav-color">Explore</button>
            </div>
          </div>
        </div>
        <div className="text-center bg-purple-800 pb-[100px] text-white">
          <button className="py-[8px] px-[12px] bg-custom-nav-color transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-100 hover:rounded-full duration-300">Explore More</button>
        </div>
      </div>
    </main>
  )
}

export function Contact_form() {
  return (
    <main>
      <div className="">
        <div className="bg-purple-600 rounded-[48px] basis-[800px] pt-[50px] pl-[150px] pb-[50px]">
          <h1 className="text-white text-5xl font-extrabold text-center pb-[16px]" id="contact-us">Let's Talk</h1>
          <h1 className="text-white font-extrabold pl-[6px]">Name</h1>
          <div className="mb-[4px]" id="name"><input className="border-none rounded-[10px] px-[24px] py-[8px]" placeholder="Name" type="text" /></div>
          <h1 className="text-white font-extrabold pl-[6px] pt-[12px]">Email</h1>
          <div className="mb-[4px]"><input className=" rounded-[10px] border-none px-[24px] py-[8px]" type="email" placeholder="Email" name="Enter email" id="" /></div>
          <h1 className="text-white font-extrabold pl-[6px] pt-[12px]">Message</h1>
          <div className=""><input className="rounded-[10px] pb-[200px] pr-[300px] pl-[24px]" type="text" placeholder="Message" name="Enter email" id="" /></div>
          <button className="text-white font-bold px-[20px] py-[8px] rounded-2xl bg-blue-500 mt-[8px] transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-100 hover:rounded-full duration-300">Submit</button>
        </div>
      </div>
    </main>
  )
}
export function Login_form() {
  return (
    <main>
      <div className="">
        <div className="bg-purple-600 text-center align-middle justify-center rounded-[48px] basis-[800px] pt-[50px] pl-[60px] pb-[50px]">
          <h1 className="text-white text-5xl font-extrabold text-center pb-[16px]" id="contact-us">Login</h1>
          <h1 className="text-white font-extrabold pl-[6px] mr-[185px] pt-[12px]">Email</h1>
          <div className="mb-[4px]"><input className=" rounded-[10px] border-none px-[24px] py-[8px]" type="email" placeholder="Email" name="Enter email" id="" /></div>
          <h1 className="text-white font-extrabold pl-[6px] mr-[185px] pt-[12px]">Password</h1>
          <div className=""><input className="rounded-[10px] px-[24px] py-[8px]" type="password" placeholder="Password" name="Enter email" id="" /></div>
          <button className="text-white font-bold px-[35px] mr-[10px] ml-[150px] py-[8px] rounded-2xl bg-blue-500 mt-[8px] transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-100 hover:rounded-full duration-300">Login</button> <Link href=""><button className="text-white font-bold px-[35px] mr-[150px] py-[8px] rounded-2xl bg-gray-800 mt-[8px] transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-100 hover:rounded-full duration-300">Register</button></Link>
        </div>
      </div>
    </main>
  )
}
export function Register_form() {
  return (
    <main>
      <div>
        <div className="bg-purple-600 text-center align-middle justify-center rounded-[48px] basis-[800px] pt-[50px] pl-[60px] pb-[50px]x">
          <h1 className="text-white text-5xl font-extrabold text-center pb-[16px]" id="contact-us">Register</h1>
          <h1 className="text-white font-extrabold mr-[185px] pl-[6px]">Name</h1>
          <div className="mb-[4px]" id="name"><input className="border-none rounded-[10px] px-[24px] py-[8px]" placeholder="Name" type="text" /></div>
          <h1 className="text-white font-extrabold pl-[6px] mr-[185px] pt-[12px]">Email</h1>
          <div className="mb-[4px]"><input className=" rounded-[10px] border-none px-[24px] py-[8px]" type="email" placeholder="Email" name="Enter email" id="" /></div>
          <h1 className="text-white font-extrabold pl-[6px] mr-[185px] pt-[12px]">Password</h1>
          <div className=""><input className="rounded-[10px] px-[24px] py-[8px]" type="password" placeholder="Password" name="Enter email" id="" /></div>
          <button className="text-white font-bold px-[35px] mr-[10px] ml-[150px] py-[8px] rounded-2xl bg-blue-500 mt-[8px] transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-100 hover:rounded-full duration-300">Register</button> <Link href=""><button className="text-white font-bold px-[35px] mr-[150px] py-[8px] rounded-2xl bg-gray-800 mt-[8px] transition ease-linear hover:bg-custom-purple hover:translate-y-1 hover:scale-100 hover:rounded-full duration-300">Login</button></Link>
        </div>
      </div>
    </main>
  )
}
export function Qualities_BuildTrust_Card() {
  return (
    <main>
      <div>
        <div className="flex text-center bg-purple-800 justify-end pr-[96px] pt-[25px]">
          <div className="bg-orange-300 px-[40px] py-[150px] mr-[8px] mb-[8px] basis-1/3">
            <Image src={delivery} alt="delivery" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Quick Delivery</h1>
            <p className="text-lg text-left font-medium font-sans">Working at the top of our speed to meet your business needs</p>
          </div>
          <div className="bg-violet-500 px-[40px] py-[150px] basis-1/3 mb-[8px] rounded-3xl">
            <Image src={quality} alt="quality" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Up-To-Mark Quality</h1>
            <p className="text-lg text-left font-medium font-sans">Quality over Quantity, get the best version of our demand</p>
          </div>
        </div>
        <div className="flex bg-purple-800 justify-end pr-[260px]">
          <div className="bg-red-400 text-center px-[40px] py-[150px] basis-[420px] mr-[8px] rounded-3xl">
            <Image src={responsiveDesigns} alt="responsive designs" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Responsive Designs</h1>
            <p className="text-lg font-medium font-sans">Our website designs are deep friends with mobile and tablet devices</p>
          </div>
          <div className="bg-blue-400 text-center px-[40px] py-[150px] basis-[420px] rounded-full">
            <Image src={cleanui} alt="clean ui" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Clean UI</h1>
            <p className="text-lg font-medium font-sans">Easy navigation, no too complex nor too simple, just Elegant</p>
          </div>
        </div>
        <div className="flex text-center bg-purple-800 justify-end pr-[40px]">
          <div className="bg-emerald-200 px-[40px] py-[150px] basis-[420px] mt-[8px] mr-[8px]">
            <Image src={cleancode} alt="clean code" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Easy-To-Understand Code</h1>
            <p className="text-lg text-left font-medium font-sans">Our coding capablities along with organization and cleanliness will inspire developers</p>
          </div>
          <div className="bg-amber-100 px-[40px] py-[150px] mt-[8px] basis-[420px] rounded-3xl">
            <Image src={ModernTechnologies} alt="technologies" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Modern Technologies</h1>
            <p className="text-lg text-left font-medium font-sans">We use Modern Technologies like Nextjs, Reactjs, Typescript, GSAP, and much more to bring your website to breathe</p>
          </div>
        </div>
        <div className="flex bg-purple-800 justify-end pr-[460px] pb-[80px]">
          <div className="bg-yellow-200 px-[40px] py-[150px] basis-[420px] mt-[8px] mr-[8px] rounded-full">
            <Image src={BudgetFriendly} alt="budget friendly" className="ml-[96px]" width={130} height={130}></Image>
            <h1 className="font-extrabold text-5xl pb-[14px]">Budget Friendly</h1>
            <p className="text-lg text-left font-medium font-sans">All these benefits witout harming the pocket, it is all about the bond we make</p>
          </div>
        </div>
      </div>
    </main>
  )
}