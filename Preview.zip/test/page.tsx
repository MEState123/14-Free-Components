import { Navbar } from "@/app/page";
import { Info_card } from "@/app/page";
import { Testimonial_Card } from "@/app/page";
import { Single_client_testimonial } from "@/app/page";
import { Features } from "@/app/page";
import { Faqs } from "@/app/page";
import { Vertical_Testimonials } from "@/app/page";
import { Search_bar } from "@/app/page";
import { Footer } from "@/app/page";
import { Portfolio_showcase } from "@/app/page";
import { Contact_form } from "@/app/page";
import { Login_form } from "@/app/page";
import { Register_form } from "@/app/page";
import { Qualities_BuildTrust_Card } from "@/app/page";


export default function test(){
    return(
        <main className="">
            <div className="">
                <Navbar/>
                <Info_card/>
                <Testimonial_Card/>
                <Single_client_testimonial/>
                <Features/>
                <Faqs/>
                <Vertical_Testimonials/>
                <Search_bar/>
                <Footer/>
                <Portfolio_showcase/>
                <Contact_form/>
                <Login_form/>
                <Register_form/>
                <Qualities_BuildTrust_Card/>
            </div>
        </main>
    )
}